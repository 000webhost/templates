Template 110625 First Light Web Design 2006.
Decorative Freeware Font: Exocet.
You can find the font at www.flashkit.com.

Thanks for downloading one of my designs. Good luck with your site! 
 
Contact: terry@firstlightwebdesign.com
--------------------------------------------------------------------------------------------
License / Terms of Use

Your use of the template signifies both acknowledgement and agreement with the following:

This work is licensed under the Creative Commons Attribution 2.5 License. To view a copy of this license, visit http://creativecommons.org/licenses/by/2.5/ or send a letter to Creative Commons, 543 Howard Street, 5th Floor, San Francisco, California, 94105, USA. You may use this template freely for both personal and commercial for-profit web sites. You are required to leave the "Design by First Light" with the hyperlink in the footer of the page. If this template is redistributed all files including this one must be included and unaltered.    

This template is provided "as is" and without warranty either expressed or implied. While every effort is made to create useful, and technically sound designs, you are solely responsible for evaluating the template's content, accuracy, merchantability, or quality. The user agrees the designer of the template shall not be liable for any alleged 
damages caused by the use of the template. You are solely responsible for adding your own content. The template is made available without any promise of technical support.
--------------------------------------------------------------------------------------------
Tips and Info

If you want to change fonts and/or add your site name and logo, I supplied a blank top background image (uncompressed jpg) so you can customize the template. I strongly recommend converting the jpg to a bitmap before performing any changes. Then convert back to a jpg and apply whatever level of compression you feel is necessary. It is a tradeoff between size in kb and image quality, so use your best judgment.    

The main thing you need to keep in mind when you upload the files to your server is to keep everything in the same folder. You should have a main directory usually "public" with all the html pages, the css file, and a folder containing the images (structured just as it is in the folder you downloaded).    

I would certainly like to be able to help with all problems that may arise with configuring your template, but simply due to time constraints I can not make any promises. Try to resolve issues through other means and contact me as a last resort.     

    
     
