Author: Kl�ra Frolichov� <info@sunlight.cz>
http://www.sunlight.cz

Requirements
---------------------------------------------------------------------------
-- Adobe Photoshop

Files
---------------------------------------------------------------------------
Photoshop Files (psd)
-- all.psd

Website Template
-- index.html
-- default.css

img (images)
readme.txt

Using rules
---------------------------------------------------------------------------
-- You cannot remove: author, Copyright, design in META tags
-- You cannot remove "Design by: Sunlight webdesign" and the link http://www.sunlight.cz from the footer of the template.
-- You cannot claim that you designed the template.

If you don't agree to any of the terms above then you may not use our template.


As long as the above conditions are met
---------------------------------------------------------------------------
-- You can use the templates for your personal use.
-- You can use the templates for your company/corporate use.
-- You can use the templates for your client's websites as long as the "Design by: Sunlight webdesign" text and it's link stays intact.

Have a nice setup.
SUnlight webdesign, www.sunlight.cz


