This free template is provided as "Linkware".

We have included a link to http://webdevelopmentquote.com in the footer of this template and if you wish to use this template, this link must remain in place and visible.

You may not remove, comment the code or obfuscate the code in any way such that it makes it invisible or unseen to the visitor of your website.

You may not resell this design or distribute in any way without the expressed written consent of Finer Design, LLC. If these terms are not acceptable to you, then you may not use this template for any reason.

If you do not want to display the link to http://webdevelopmentquote.com , then we invite you to purchase a template from our collection of templates located at: http://www.finerdesign.com/website-templates/website-templates.php

Thank you