	

Terms of Usage

By downloading and/or using one of inhead s.c. free web site templates you are legally bound by the following:

Users must at all times keepp the text link with anchor "Pozycjonowanie" to inhead s.c. main site, on the front page of their web site. By violating linking rules you fully understand you are committing Copyright infringement, and are in breach of contract.

The templates may be used for personal or business web sites but you may not put them on a diskette, CD, web site or any other medium and offer them for redistribution or resale.

Inhead s.c. templates are offered "as is" without warranty of any kind, either expressed or implied. Inhead s.c. will not be liable for any damage or loss of data whatsoever due to downloading or using a template.

Inhead s.c. reserves the right to change and/or modify these terms with no prior notice. Understand this is a legally binding contract, and violation will have consequences where this document may be used against you.
