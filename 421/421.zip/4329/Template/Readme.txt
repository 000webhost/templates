Thank you for choosing one of our website templates which you may use freely
as long as the link to Cigaro's website is in place next to the copyright notice.

If you need help to customize this template you can contact Cigaro's support
at support@cigaro.se and we will do it for you for only 49�. If you want a
complete new design customized for you we do websites starting at 499� per
unique design. We can also offer programming of advanced features for your
websites such as guestbooks, forum, live webcam and a lot more! Visit our
website at http://www.cigaro.se for more information about our services!

This template was downloaded from FreeLayouts.com, please visit this
website for more free layouts for your website!