
------------------------------------------------------

instructions:

1.) unzipped files with winzip



2.) To edit the photoshop PSD file you must have Photoshop 7.0+ installed on your computer.
To edit the text you must first install the font(s) included with this template by copying 
them to your fonts folder in C:\WINDOWS\FONTS.

3.) open .html files with Dreamweaver, a Text Editor, Netobjects, Adobe GoLive  or Microsoft Frontpage.

4.) To edit the text in the PSD file just click the text edit button in photoshop and then
the text. After making all the changes neccesary you must click 'save for the web.' in the file
menu and then choose your format (bmp,jpg,gif or png) gif is probably the best. Then you must choose
the folder where you would like to save the sliced files. This will create a slice.html file
and a images folder. Then you can move them around (if you move the images elsewhere you have to
also change the HTML code!)

Sources Available:
.PSD;
.HTML;
fonts used

------------------------------------------------------

