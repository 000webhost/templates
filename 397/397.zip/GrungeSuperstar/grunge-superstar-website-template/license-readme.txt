>> License Agreement (http://templates.arcsin.se/license/)
-------------------------------------------------
This template is licensed under a Creative Commons Attribution 2.5 License.
http://creativecommons.org/licenses/by/2.5/

You are free:

    * to Share � to copy, distribute, display, and perform the work
    * to Remix � to make derivative works

Under the following conditions:

    * Attribution. You must attribute the work in the manner specified by the author or licensor.
    * For any reuse or distribution, you must make clear to others the license terms of this work.
    * Any of these conditions can be waived if you get permission from the copyright holder.

Attribution:

    * Must include the provided link back to my website.

This means that you are free to use and modify the templates & themes for any purpose, but you must include the provided link back to my website.


>> Removing the link (Commercial & Personal use)
-------------------------------------------------
I have agreed to let users remove the link for a one time fee of $20 (US Dollars).

Payment can be done via:

    * Moneybookers: moneybookers@arcsin.se
    * PayPal: paypal@arcsin.se
    * Credit card: Follow the instructions found at the template license page: http://templates.arcsin.se/license/ 

This gives you permission to remove the provided link on one template for one domain, for a corporate license (unlimited use on unlimited domains) please contact me.

Please include the website URL in the payment message so I can save it in my list of verified websites.


>> Note
-------------------------------------------------
Removing the link (not paid for) is the same as breaking the law and action can be taken against you.


>> Contact
-------------------------------------------------
Author: Viktor Persson
Email: contact@arcsin.se
Website: http://arcsin.se/