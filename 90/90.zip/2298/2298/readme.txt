Usage of E-Nordstrom.com Free Web Templates require a link-back at your home page
in order for us to expand this service.

Linking Information:

<a href="http://www.e-nordstrom.com/subpages/website.asp">Design By: E-Nordstrom</a>

Or 

<a href="http://www.e-nordstrom.com/subpages/website.asp">Free Web Templates</a>


This is a small favor for using our templates. This will also help us expand this service.
Pls. note that you may NOT use our templates if you do not abide by this policy. 


Best Regards,
E-Nordstrom 