<?
/*
  Welcome to the style engine of Tuned Studios
   
  For detailed information on how this engine works, visit the support section of tunedstudios.com

  Copyright (C) 2005  Roland van Dijk
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/
  

  //Alright, let's get started.
  
  //First we include the header file. 
  include('engine/header.engine.php');
  
  //Then we include the body top file
  include('engine/body_top.engine.php');
  
  //Now, it's to include the current page.
  
  //First check if $page exists
  if(isset($page))
  {
      //Check if the page $page exists
      if(file_exists($page))
      {
           //Now we can include the page.
           include($page);
      }
      else
      {
           //Page can't be found, include the error file
           include('data/error404.data.php');
      }
  }
  else
  {
      //Include the default error page
      include('pages/home.php');
  }
  
  //Include the closing body part
  include('engine/body_bottom.engine.php');

  //Include the footer
  include('engine/footer.engine.php');


?>