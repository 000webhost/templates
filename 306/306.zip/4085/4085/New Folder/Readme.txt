                
                        ____________________________________________
                        |                                          |
                        |       _____                              |     
                        |      / ___ \                             |           
                        |     /\ \_/\ \     ______     ______      | 
                        |     \ \ \\_\ \   / ____ \   / _____\     |
                        |      \ \  ___<  /\ \__/\ \ /\ \____/     |
                        |       \ \ \_/\ \\ \ \ \ \ \\ \ \         | 
                        |        \ \ \\ \ \\ \ \_\_\ \\ \ \____    |   
                        |         \ \_\\ \ \\ \______/ \ \_____\   |
                        |          \/_/ \/_/ \/_____/   \/_____/   |
                        |__________________________________________|

                +-----------------------------------------------------------+
		�   	     Gray Haze   HTML Template       2006           �       
		�      	     created by Rock                                �              
		+-----------------------------------------------------------+


Before using the template, you must comply to the following policy:

You may:
� use the template on your website.
� upload the template to your server.
� modify the template.
� redistribute the template.
� resell the template.
� modify the template before reselling or redistributing (ex. adding a link to your website).

You may not:
� Take credit for this template in anyway.
� Remove or modify the link to http://www.cpgclan.com on at the bottom.
� Remove Theme designed by Rock � 2006 CpG Clan (Rock is a email link & CpG Clan is my link.
� claim ownership of the template.

All you need to do:
�Edit the banner(cpg_03.gif) in what ever photo editer you use.
�Udit the pages in the content folder. 
�Unless you don't link iframes don't edit the index page much.
�That's it!!!!

Note: This template was created for 1024x786 resolution systems, so if you want to use on lower resolutions set stretch to page. 