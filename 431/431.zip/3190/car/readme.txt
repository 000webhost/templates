---------------------------------------------------------------
Thankyou for choosing to download a template by Lauhost.com

ONLY REQUIREMENTS:
- That you keep at least one of our banner that link back to Lauhost.com on the frontpage. And keep the symbol (read : L) on the bottom at every pages.
- Read Term of use below!
----------------------------------------------------------------

LAUHOST.COM
TERMS OF USE AND NOTICES
PLEASE READ THESE TERMS AND CONDITIONS OF USE CAREFULLY BEFORE USING THIS SITE. 
Template by Lauhost.com terms of use (free templates) 

By downloading and using the free templates from lauhost.com  you agree to the following License Agreement: 

* You may use our free templates for personal or business.

* You are free to distribute these free templates. The only restriction is you must provide a link back to Lauhost.com. Note: You cannot remove banner that link back to Lauhost.com.

* These free templates shall not be used for websites dealing with sex, violence, or any illegal contents.

* The free templates are provided "as is" without warranty of any kind, either expressed or implied. 

* You understand that Lauhost.com is not responsible for the content, quality or merchantability of any information, product or service offered herein and the user must assume full responsibility to evaluate independently the accuracy completeness, quality and usefulness of any information or other content. 

* You may not claim our free templates as your own work. Copyright ownership remains with Lauhost.com 

* Lauhost.com reserves the right to change and/or modify these terms with no prior notice

* You must keep at least one of our banner that link back to Lauhost.com on your FRONT PAGE. Use the banner provided.

* You must keep little symbol (read : L) that link back to Lauhost.com on every pages.