-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

             Landmarks - Subtle WTC - Template @ Geesh.com - ReadMe

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------


                     ..................................
                         Template Directions
                     ..................................


After Unzipping, you can open the "index.html" file in an html editor (i use notepad) and follow the directions to modify the site's title.  Remember to save the text file as "index.html", as all filenames are case-sensitive!

Upload all graphic and html files into the same directory, if you don't, the template will not work.

When browsing through the "index.html" file, you will see that certain areas of the file have comments regarding where your main page elements are located.  These usually include the main link area and site text area.  Modify these with your links and site content, and you're ready to go.

All I require in return for the free template is that you keep in place one of the following: "Design by Geesh" footer text, or a button/text link to Geesh.com somewhere in your navigation.  This is usually near one of the main site graphics and it is intended to clearly display that this is a copyrighted work of art licensed for use at your website.

If you decide to use the template, please send me an e-mail with your site address to webmaster@geesh.com, or visit the forums over at forums.geesh.com  I'd like to see everyone's different websites and I might set up a links list with address' to template-powered sites to help increase your site traffic.

Good Luck with your site and thanks for using a Geesh.com Template! I am always adding more templates to the site, so feel free to come back anytime. http://www.geesh.com


                     ..................................
                             Terms of Use
                     ..................................

In Addition to the graphical requirements of using the template (as above), You must also understand that these templates are protected by copyright law and by using the template you agree to the conditions that are set out in this readme file.  I go to some hard work putting these templates together to give away at NO COST, and I expect some respect in return.  In the past I have had to revoke some site's from using my templates because they had deleted all signs of recognition of where the template has come from.  That is a violation of copyright law.  If the template is downloaded and used i would love to hear from you.  I do keep track of the templates and if one is found abusing the graphical requirements or policies then i will revoke your license to use the templates (but i really dont want to! Please!)

Doug,
http://www.geesh.com  - Geesh.com Website Templates