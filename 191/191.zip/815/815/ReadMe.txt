Template By Web I Weave, Internet Web Site Design Company
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
If you did not get this from Web I Weave, please take drop by my site at http://www.webiweave.com/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Thank you for downloading this template, if you like it, please let me know.

Terms of use, This template is Linkware you can use it all you like, but you must leave the Designed by Web I Weave, at bottom of the web page intact. You may not use any graphic's and/or html coding in this template to create another template, you may not post this template elsewhere without permission, in addition the html code inside this file is for personnel 
or commercial use, and can not be redistributed by any means.

If you can not follow this, then do not use this template. I hold the right to make sure your site will be shut down under any violation of these terms.

If you still do not want to follow these terms you must pay me $25 US. but still under no circumstances can you re-sell or use anything in this template, to create another.

This zip includes the following.

index.html
 ReadMe.txt
 style.css 
the images that come with this template.  

Style.css can be edited in any notepad program.

If you have any questions or problems you can email me at the address listed on my web site, www.webiweave.com

If you want the template customized for your site, I charge $50 for this.

What you get for your $50, 
Link text changed and linking to where you want them to.
Your banners and other graphic's.
Your front page content.

Note:
This is only for the main page of your site, I am not customizing a site, just the main page. You will have to do the rest on your own.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				(C)Copyright 2003-2004 Web I Weave, 
				Internet Web Site Design Company
				ALL RIGHTS RESERVED


