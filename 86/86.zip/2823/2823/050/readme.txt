jacobstom.net templates were made using Macromedia Fireworks MX or swish. 
They are raw templates and you must have a good knowledge of html and/or swish to modify or edit the file. Best bet is to obtain Adobe Photoshop or Macromedia Fireworks to edit and finalize.

By using my templates you abide to the following:

a) LIMITED USAGE GRANTED
You may only use each individual product on a single website, belonging to either you or your client. You have to purchase the template if you intend to use the same template or design once more for a different project.
b) MODIFICATIONS
You are authorized to make any necessary modification(s) to my products to fit your purposes.
c) UNAUTHORIZED USE
You may not place any of my products, modified or unmodified, on a diskette, CD, website or any other medium and offer them for redistribution or resale of any kind without prior written consent from myself.  
d) ASSIGNABILITY
You may not sub-license, assign, or transfer this license to anyone else without prior written consent from me.
e) OWNERSHIP 
You may not claim intellectual or exclusive ownership to any of my products, modified or unmodified. 

My products are provided "as is" without warranty of any kind, either expressed or implied. In no event shall my person be liable for any damages including, but not limited to, direct, indirect, special, incidental or consequential damages or other losses arising out of the use of or inability to use my products.

For more info or if you need some assistance contact me using the online form at 
http://www.jacobstom.net 