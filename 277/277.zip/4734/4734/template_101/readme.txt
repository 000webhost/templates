|||||||||||||||||||||||||||||||||||||||||||||||||

spyka.net Web Template [READ ME] 20:31 25/01/2007

|||||||||||||||||||||||||||||||||||||||||||||||||

Free web template by spyka.net.



1. Customizing this template
-----------------------------------------
To change the text, content, links etc. open the index.htm in your preferred HTML editor, 
whether it be notepad, dreamweaver of frontpage.

To change the CSS open images/index.css in a HTML/CSS editor and change the appropriate 
values to suit your needs.

Need more help? Don�t be afraid to get in touch - spyka.net/contact


2. Paid template customisation
-----------------------------------------
We can customise this template for you from �10, that can include changing images, 
colour schemes, navigation links, adding content and page structure changes.

Check out spyka.net/services for more info.


3. Terms of use
-----------------------------------------
This template is FREE to use as long as the following conditions are met:

		* A link back to spyka.net is required, however can be removed (see 4. Template licence.)
                * You must no claim the work is your own
                * You understand you DO NOT have permission to re-distribute the work
		* The work must remain FREE. 
			- It must not be included in any commercial package
			- It must not require a fee to download and/or use
			- It must not be available inside any software.


4. Template Licence
-----------------------------------------
The link back to spyka.net and any other copyright/information relating to spyka.net can 
be removed with the purchase of a template licence. A licence costs �3.30 (Approx $6USD) 
per template per site and gives the site owner/webmaster to remove this information.


5. Other information
-----------------------------------------
Please contact us if you need more information about template licences, use of our templates
or other queries - spyka.net/contact
