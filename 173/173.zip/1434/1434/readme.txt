Logodesignwebs template 
Thank you for downloading one of our template designs.

Instruction
1. To customise the template open back.jpg in an image editor and insert your websites name
in the image.

2. Open index.htm and insert your text.


License
You may use this template in your website, both non-commercial and commercial. The footer
links must remain as is and fully viewable. 
You are not allowed to redistribute the template without permission.


/Johnny Magnusson
