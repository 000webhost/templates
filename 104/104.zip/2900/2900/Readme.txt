bobblewiz Web Templates
[chr02]

This template is free to use for both personal and commercial sites. It must NOT be sold or included as part of any other package. The only conditions of use are that you leave both the link to http://bobblewiz.50webs.com and the 'author' meta tag 'as is', on each page.

The template has two pages ...main index page, and a 'sub' page that is used for all other pages. Both pages utilise scroll boxes so that the navigation buttons remain in view at all times. Buttons have mouseover effects

It is relatively simple to insert your own text, images etc... easily achievable with a basic text editor such as 'notepad'. If you have any problems, this can be done for you for a [small] fee  ...or, for a slightly BIGGER [small] fee, the template can be customised to your requirements (button titles, meta tags, etc.)

...email bobblewiz@hotmail.com

...visit http://bobblewiz.50webs.com
   for web templates, web design, free sound samples/loops and more [stuff]

