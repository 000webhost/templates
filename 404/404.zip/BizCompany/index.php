<html>
<head>
<title>-:: We Design Site ::-</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="Desciption" content="This web design site is a very good site with wonderful web design resources">
<meta name="keywords" content="This,web,design,site,is,a,very,good,site,with,wonderful,web,design,resources">
<link href="style/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<center>
<div class="wrapper">
<div class="header">
<div style="float:left; margin-left:110px; margin-top:20px;">
<img src="images/logo.jpg" style="float:left;">
<div style="float:left;  text-align:left; font-family:tahoma; font-size:24pt; color:#636363; margin-left:5px;margin-top:5px;">Business<b>Logo</b><br><span style="float:left;  text-align:left; font-family:tahoma; font-size:8pt; color:#b1b1b1;"><b>&nbsp;best business in town</b></span>
</div>

</div>

<div style="float:right; margin-right:30px; margin-top:50px; text-align:left; font-family:tahoma; font-size:17pt; color:#636363;">the best media <b>solutions</b><br><span style="float:left;  text-align:left; font-family:tahoma; font-size:8pt; color:#b1b1b1;"><b>&nbsp;best business in town</b></span>
</div>

</div>
<div class="menu">
<div class="menu-text" style="padding-left:140px;padding-right:50px;"><a href="#" class="nav">Home</a></div>
<div class="menu-text"><a href="#" class="nav">About</a></div>
<div class="menu-text"><a href="#" class="nav">Media</a></div>
<div class="menu-text" style="padding-right:30px;"><a href="#" class="nav">Products</a></div>
<div class="menu-text"><a href="#" class="nav">Contact</a></div>

<div style="float:right; padding-right:25px;padding-top:12px;">
<input type="image" src="images/go.jpg" />
</div>
<div style="float:right;padding-right:8px;padding-top:14px;">
<input style="border:none; height:18px;width:130px;" type="text" name="search_box" />
</div>

</div>

<div class="first-section">
<div class="right-image">
<div class="title1">A Personal Touch</div>
<div class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
<img src="images/personal.jpg" style="margin-left:12px;">
<div class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempoiyt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet..&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/more.jpg"></div>
</div>
<div class="mid-image">&nbsp;</div>
<div class="left-image">
<div class="title1" style="color:#ffffff; border-bottom:solid 1px #00deff; width:200px; padding-bottom:7px;">Website&nbsp;<span class="title2" style="color:#ffffff;">News</span>
</div>
<div class="date-text">Site Update &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;31/12/2007</div>
<div class="description" style="color:#ffffff; border-bottom:solid 1px #00deff; width:200px; padding-bottom:7px;padding-top:5px;"><b>Lorem ipsum</b> dolor sit amet cttur ing elit, sed do eiusmod tempnti doloregna aliqua. Uties for enis..</div>
<div class="date-text">Site Update &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;31/12/2007</div>
<div class="description" style="color:#ffffff; width:200px;padding-top:5px;"><b>Lorem ipsum</b> dolor sit amet cttur ing elit, sed do eiusmod tempnti doloregna aliqua. Uties for enis..</div>
</div>
</div>

<div class="wrapper">



<div style="float:right; width:675px">
<div class="second-section">
<div class="pack-box3">
<div class="title1">Client Pack&nbsp;<span class="title2">Three</span></div>
<div class="sub-title">Great Oak Pack</div>
<div class="description">Lorem ipsum dolor sit amet, consectiurn adipisicing elit, sed do eiusmod tempont ut labore et dolore magna aliquaiam uis nostrud exercitation..&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/more.jpg"></div>
</div>
<div class="pack-box2">
<div class="title1">Client Pack&nbsp;<span class="title2">Two</span></div>
<div class="sub-title">Growth Pack</div>
<div class="description">Lorem ipsum dolor sit amet, consectiurn adipisicing elit, sed do eiusmod tempont ut labore et dolore magna aliquaiam uis nostrud exercitation..&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/more.jpg"></div>
</div>
<div class="pack-box1">
<div class="title1">Client Pack&nbsp;<span class="title2">One</span></div>
<div class="sub-title">Saplink Pack</div>
<div class="description">Lorem ipsum dolor sit amet, consectiurn adipisicing elit, sed do eiusmod tempont ut labore et dolore magna aliquaiam uis nostrud exercitation..&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/more.jpg">
</div>

</div>
</div>

<div class="third-section">
<div class="down-box2">
<div class="title3">Testimonial</div>
<div class="description">
�Lorem ipsum dolor sit amet, consecttur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magnaaliqua. Lorem ipsum dolor sit ame adipisicing somar elle vio tar nero magna puro elit..�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/more.jpg">
</div>
</div>
<div class="down-box1">
<div class="title3">Why we're Special</div>
<div class="description1">
<img src="images/special.jpg" style="float:right; margin:3px; margin-left:5px;">
Lorem ipsum dolor sit amet, consecteturp elitd do eiusmod tempor incididunt ue et doloreagna aliqua. Ut enim ad minim veniam, quis nostrudi. Sedim, veil tu so marre, poller toniam so purte.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ididunt ut labore et dolore magna aliqua. Ut enim ad minim..&nbsp;<img src="images/more.jpg">
</div>
</div>
</div>
</div>

<div class="left-section">
<div class="left-box2">
<div class="title1" style="margin-left:0px">Treating Clients Well</div>
<img src="images/client.jpg">
<div class="description" style="margin-left:0px">Lorem ipsum dolor sit amet, consecttur adipisicing elit, sed do eiusmod tempot ut labore et dolore magna aliqua. Utim ad minim veniam..&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/more.jpg"></div>
</div>
<div class="left-box1">&nbsp;</div>
</div>

</div>

<div class="footer">
Copyright Business Company (c) 2007, All rights Reserved.
</div>

</div>
</center>
</body>
</html>