This template is sponsored by http://Www.design-universe.net

Thank you for using this Template and visit my site soon again ;)


Information:
Normally all the templates are sliced. An index.html file should
be created and included too.


mfg rizzn
www.design-universe.net