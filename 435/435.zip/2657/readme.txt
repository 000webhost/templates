Hey!
Thanks for downloading something.This is free as long as you link back to my site
it dosent have to be a large link just a simple "design by ghettodesings.com" down
at the bottom will be fine. thanks

   ~ Webmaster@ghettodesigns.com