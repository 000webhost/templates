you can buy an (c)-free version for only 9,99 Us-$ ( PayPal ) + modifications !

contact me: mydesign@gmail.com
contact me: info@karwe.biz

visit WWW.KARWE.BIZ

===

Our web templates may be used for your own and/or your clients' websites, but you may offer for free our templates in any sort of collection, such as distributing to a third party via CD, diskette, or letting others to download off your websites etc. but you may contact us, if you use it for selling.

If you download our free web templates then link back to www.karwe.biz is required and always appreciated.

The templates are offered "as is" without warranty of any kind, either expressed or implied. Karwe.biz will not be liable for any damage or loss of data whatsoever due to downloading or using a template. In no event shall TemplatesBox.com be liable for any damages including, but not limited to, direct, indirect, special, incidental or consequential damages or other losses arising out of the use of or inability to use the templates and/or information from Karwe.biz.

Karwe.biz team reserves the right to change or modify these terms with no prior notice.

===