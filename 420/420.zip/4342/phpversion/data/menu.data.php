<!-- This are the links from the left menu. -->
                         <li><a href="index.php" title="Home">Home</a></li>
                         <li><a href="?page=pages/about" title="About">About</a></li>
                         <li><a href="?page=pages/templates" title="Webdesign">Webdesign</a></li>
                         <li><a href="?page=pages/music" title="Music">Music</a></li>
                         <li><a href="#" title="Contact">Download</a></li>
                         <li><a href="#" title="Contact">Contact</a></li>