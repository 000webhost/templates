<body>

<div id="container">
<div id="core_header">
     <div id="header_text"><? include("data/title.data.php"); ?></div>
</div>

	<div id="core_container">
	<div id="core_container2">

		<div id="core_left">
		     <div id="navcontainer">
		     <br />
		     <br />
                     <ul>
                     <?
                       include("data/menu.data.php");
                     ?>
                     </ul>
		     </div>
		</div>
		<div id="menubalktop">
                <? include("data/menu_top.data.php"); ?>
                </div>
       <div id="core_right">
       <div id="pagecontent">


