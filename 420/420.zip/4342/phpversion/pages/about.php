<div class="content-box">
       <h3>About</h3>
       Your content goes here.
</div>