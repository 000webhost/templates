** IMPORTANT NOTICE **

This template is available under the following license: http://creativecommons.org/licenses/by/2.5/

You must keep the Free Layouts.com link intact, or link us somewhere else on every page on which the template is used.