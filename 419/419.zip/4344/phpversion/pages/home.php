<div class="content-box">
       <h3>Template Engine</h3>
       <img src="images/tumb1.jpg" style="float:left; margin-left:0px;" alt="img" />
       Tuned Studios proudly presents this layout to you!
       <br /><br />
       This template is only for those who can resist the coolest and coldest designs. We hope you find it usefull.
<br /><br />
How to use our template engine? Well, a README file is included inside the zip. You can find installation instructions there.
</div>

<div class="content-box">
        <h3>Welcome</h3>
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam eu quam. Nulla sed purus in ipsum sagittis eleifend. Maecenas eget nulla. Vivamus et turpis a est venenatis eleifend. Nulla quam magna, consequat vel, molestie ac, sagittis id, risus. Sed a urna. Ut convallis ullamcorper lorem. Pellentesque tempor facilisis enim. Quisque hendrerit. Donec molestie tristique sapien. Nullam viverra, arcu sit amet cursus fringilla, velit metus venenatis augue, in venenatis pede est fringilla nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.
</div>
       
<div class="content-box">
        <h3>News</h3>
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam eu quam. Nulla sed purus in ipsum sagittis eleifend. Maecenas eget nulla. Vivamus et turpis a est venenatis eleifend. Nulla quam magna, consequat vel, molestie ac, sagittis id, risus. Sed a urna. Ut convallis ullamcorper lorem. Pellentesque tempor facilisis enim. Quisque hendrerit. Donec molestie tristique sapien. Nullam viverra, arcu sit amet cursus fringilla, velit metus venenatis augue, in venenatis pede est fringilla nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.
</div>
       
