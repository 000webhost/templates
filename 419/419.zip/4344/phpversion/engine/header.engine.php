<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
   "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
   <head>

      <!--  Title displayed in top of the webbrowser -->
      <title>
             <? include("data/title.data.php"); ?>
      </title>
      
      <!-- The file with the style sheet -->
      <link href="engine/style.css" rel="stylesheet" type="text/css" />
      
   </head>

   


