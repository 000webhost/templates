<body>

<div id="container">
<div id="core_header">
     <div id="header_text"><? include("data/title.data.php"); ?></div>
</div>

	<div id="core_container">
	<div id="core_container2">

		<div id="core_left">
		     <div id="navcontainer">

                     <?
                       include("data/menu.data.php");
                     ?>

		     </div>
		</div>
       <div id="core_right">


