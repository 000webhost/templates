<!-- This are the links from the left menu. -->
                         <a href="index.php" title="Home">Home</a>
                         <a href="?page=pages/about" title="About">About</a>
                         <a href="?page=pages/templates" title="Webdesign">Webdesign</a>
                         <a href="?page=pages/music" title="Music">Music</a>
                         <a href="#" title="Contact">Download</a>
                         <a href="#" title="Contact">Contact</a>