<div class="content-box">
      <h3>Error</h3>
      An unknown error occured while browsing our site. We sincerely apologize for any inconvenience. 
</div>