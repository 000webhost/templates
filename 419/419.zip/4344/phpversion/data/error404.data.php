<div class="content-box">
      <h3>Error</h3>
      We're very sorry, but this page does not exists on our server. 
</div>