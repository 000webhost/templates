Thank you for downloading this free template! This template can be
used freely in any way you please aslong as the link on the template
to Larmdirect.se with the anchortext "Villalarm" stays
where it is down at the bottom. You may not remove this link. Furthemore
it is allowed to take this template and spread it to others that may
want to use it aslong as this textfile is with the template and not
altered in any way.

Once again thank you for downloading this template, we hope that you
will find it useful.

Cigaro Design Team
http://www.cigaro.se