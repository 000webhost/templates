-----------------------------------
  _/          _/  _/_/_/    _/_/_/    
 _/          _/  _/    _/  _/    _/   
_/    _/    _/  _/    _/  _/    _/    
 _/  _/  _/    _/    _/  _/    _/     
  _/  _/      _/_/_/    _/_/_/   
-----------------------------------

Thank you for downloading this template.

The Archive includes:

- Photoshop Source file of the template
- xHTML version along with CSS file.

Instructions:
-----------------

- Extract the archive to any folder of your hard drive.
- Open index.html file with your favorite editor and make changes as required.
- To edit graphics, open .psd file with Photoshop and change the colors or any other changes you want to make. 
- Slice the edited area with Slice TOOL and from the file menu, choose SAVE FOR WEB.

About the Template
------------------
This is an open source template and is relased and distributed under Creative Commons 2.5 licence. You are free to use this template in any way you like. All I ask for is that you leave the web site design credit links in the footer of this template intact.  As always comments are welcomed and thank you for downloading.

Credits:
-------------------------
Web Designers Directory
www.web-designers-directory.org
info@web-designers-directory.org
