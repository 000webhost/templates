
TERMS OF USE


This template is free for both private and commercial use. You can edit it to suit your needs. The link back to Alpha Studio is required. However, it can be moved to any other place.

Do not use the template in connection with sex, violence, discrimination and for other immoral or illegal purposes.

The template is offered "as is" without warranty of any kind, either expressed or implied. Alpha Studio will not be liable for any damage or loss of data whatsoever due to downloading or using this template. In no event shall we be liable for any damages including, but not limited to, direct, indirect, special, incidental or consequential damages or other losses arising out of the use of or inability to use our product.