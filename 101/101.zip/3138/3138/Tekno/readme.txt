Alright, here is the template. It was created in dreamweaver MX, should be pretty straight forward to set up, everything is there you just need to add text and images. I ask though that you place a link to my site www.wireds-domain.com. As well the image was created in photoshop CS.

If you run into any problems let me know coreygibson@wireds-domain.com

Thanks 
Corey Gibson
www.wireds-domain.com