Counter-Strike Clan Template (Inline Frames)
Thank you for downloading one of my clan templates.

Instruction
1. To customise the template open PSD\index.psd with Photoshop. Edit the headline text, Save to Web, overwrite everyting.

2. Open index.htm and insert text, polls and so on.


License
You may use this template in your website, both non-commercial and commercial. DO NOT remove the credits.
You are not allowed to redistribute the template without permission.


//Marius Melle//
