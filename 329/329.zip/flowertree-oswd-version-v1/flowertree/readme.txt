FLOWERTREE - A OPEN SOURCE TEMPLATE
----------------------------------------------------------------------
Author          : Jonas John
Official website: http://www.jonasjohn.de/lab/flowertree.htm
Last update     : Nov 18, 2006
Current version : 1.0
----------------------------------------------------------------------

flowertree is my third open source website template. It does not use 
tables, is XHTML 1.0 Strict and CSS valid :-)

I also included two alternative layouts and a print stylesheet.


Feel free to use this template for any commercial or private website!

----------------------------------------------------------------------
Uses stock photos:
----------------------------------------------------------------------

physalis mady be Proseccohead:
http://www.photocase.de/photodetail.asp?i=47596

Holzstrucktur made by Broiler:
http://www.aboutpixel.de/index.php4?toppage=imagedetails&image_id=25114

----------------------------------------------------------------------
Recent changes:
----------------------------------------------------------------------

Nov 18, 2006 - Version 1.0
- created the complete website and
  submitted the design to oswd.org


