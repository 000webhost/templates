Before using the template, you must comply to the following policy:

You may:
� use the template on your website.
� upload the template to your server.
� modify the template.
� redistribute the template.
� resell the template.
� modify the template before reselling or redistributing (ex. adding a link to your website).

You may not:
� remove or hide button.gif from the template.
� remove or modify the link to http://www.weblayouts.ws on the button.gif image.
� modify button.gif.
� claim ownership of the template.